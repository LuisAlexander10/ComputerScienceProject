﻿namespace Project
{
    partial class ViewTransaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.QtyBox = new System.Windows.Forms.TextBox();
            this.DateBox = new System.Windows.Forms.DateTimePicker();
            this.AddBox = new System.Windows.Forms.TextBox();
            this.PhoneBox = new System.Windows.Forms.TextBox();
            this.CustBox = new System.Windows.Forms.TextBox();
            this.UserBox = new System.Windows.Forms.TextBox();
            this.ProdPrice = new System.Windows.Forms.TextBox();
            this.ProdType = new System.Windows.Forms.TextBox();
            this.ProdName = new System.Windows.Forms.TextBox();
            this.ProdIDBox = new System.Windows.Forms.TextBox();
            this.TranIDBox = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(9, 8);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(472, 134);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.dataGridView1_MouseClick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.QtyBox);
            this.groupBox1.Controls.Add(this.DateBox);
            this.groupBox1.Controls.Add(this.AddBox);
            this.groupBox1.Controls.Add(this.PhoneBox);
            this.groupBox1.Controls.Add(this.CustBox);
            this.groupBox1.Controls.Add(this.UserBox);
            this.groupBox1.Controls.Add(this.ProdPrice);
            this.groupBox1.Controls.Add(this.ProdType);
            this.groupBox1.Controls.Add(this.ProdName);
            this.groupBox1.Controls.Add(this.ProdIDBox);
            this.groupBox1.Controls.Add(this.TranIDBox);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Franklin Gothic Book", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(9, 154);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.groupBox1.Size = new System.Drawing.Size(472, 217);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Order Detail";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // QtyBox
            // 
            this.QtyBox.Location = new System.Drawing.Point(85, 177);
            this.QtyBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.QtyBox.Name = "QtyBox";
            this.QtyBox.Size = new System.Drawing.Size(33, 21);
            this.QtyBox.TabIndex = 22;
            // 
            // DateBox
            // 
            this.DateBox.Location = new System.Drawing.Point(261, 27);
            this.DateBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.DateBox.Name = "DateBox";
            this.DateBox.Size = new System.Drawing.Size(135, 21);
            this.DateBox.TabIndex = 21;
            // 
            // AddBox
            // 
            this.AddBox.Location = new System.Drawing.Point(307, 150);
            this.AddBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.AddBox.Multiline = true;
            this.AddBox.Name = "AddBox";
            this.AddBox.Size = new System.Drawing.Size(145, 45);
            this.AddBox.TabIndex = 20;
            // 
            // PhoneBox
            // 
            this.PhoneBox.Location = new System.Drawing.Point(307, 125);
            this.PhoneBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.PhoneBox.Name = "PhoneBox";
            this.PhoneBox.Size = new System.Drawing.Size(145, 21);
            this.PhoneBox.TabIndex = 19;
            // 
            // CustBox
            // 
            this.CustBox.Location = new System.Drawing.Point(307, 100);
            this.CustBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.CustBox.Name = "CustBox";
            this.CustBox.Size = new System.Drawing.Size(145, 21);
            this.CustBox.TabIndex = 18;
            // 
            // UserBox
            // 
            this.UserBox.Location = new System.Drawing.Point(261, 50);
            this.UserBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.UserBox.Name = "UserBox";
            this.UserBox.Size = new System.Drawing.Size(68, 21);
            this.UserBox.TabIndex = 17;
            // 
            // ProdPrice
            // 
            this.ProdPrice.Location = new System.Drawing.Point(85, 148);
            this.ProdPrice.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ProdPrice.Name = "ProdPrice";
            this.ProdPrice.Size = new System.Drawing.Size(68, 21);
            this.ProdPrice.TabIndex = 16;
            // 
            // ProdType
            // 
            this.ProdType.Location = new System.Drawing.Point(85, 125);
            this.ProdType.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ProdType.Name = "ProdType";
            this.ProdType.Size = new System.Drawing.Size(68, 21);
            this.ProdType.TabIndex = 15;
            // 
            // ProdName
            // 
            this.ProdName.Location = new System.Drawing.Point(85, 97);
            this.ProdName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ProdName.Name = "ProdName";
            this.ProdName.Size = new System.Drawing.Size(68, 21);
            this.ProdName.TabIndex = 14;
            // 
            // ProdIDBox
            // 
            this.ProdIDBox.Location = new System.Drawing.Point(85, 50);
            this.ProdIDBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.ProdIDBox.Name = "ProdIDBox";
            this.ProdIDBox.Size = new System.Drawing.Size(68, 21);
            this.ProdIDBox.TabIndex = 13;
            // 
            // TranIDBox
            // 
            this.TranIDBox.Location = new System.Drawing.Point(85, 27);
            this.TranIDBox.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.TranIDBox.Name = "TranIDBox";
            this.TranIDBox.Size = new System.Drawing.Size(68, 21);
            this.TranIDBox.TabIndex = 12;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(128, 179);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(27, 16);
            this.label12.TabIndex = 11;
            this.label12.Text = "Pcs";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(214, 150);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 16);
            this.label11.TabIndex = 10;
            this.label11.Text = "Address";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(214, 125);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(84, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Phone Number";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(214, 99);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(91, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Customer Name";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(5, 177);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(52, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "Quantity";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(5, 150);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(77, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Product Price";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 125);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(74, 16);
            this.label6.TabIndex = 5;
            this.label6.Text = "Product Type";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(5, 99);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 16);
            this.label5.TabIndex = 4;
            this.label5.Text = "Product Name";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(214, 50);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(45, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "User ID";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 27);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Date";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 50);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(62, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Product ID";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(5, 27);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Transaction ID";
            // 
            // ViewTransaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.ClientSize = new System.Drawing.Size(497, 379);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dataGridView1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ViewTransaction";
            this.Text = "ViewTransaction";
            this.Load += new System.EventHandler(this.ViewTransaction_Load);
            this.MouseClick += new System.Windows.Forms.MouseEventHandler(this.ViewTransaction_MouseClick);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox QtyBox;
        private System.Windows.Forms.DateTimePicker DateBox;
        private System.Windows.Forms.TextBox AddBox;
        private System.Windows.Forms.TextBox PhoneBox;
        private System.Windows.Forms.TextBox CustBox;
        private System.Windows.Forms.TextBox UserBox;
        private System.Windows.Forms.TextBox ProdPrice;
        private System.Windows.Forms.TextBox ProdType;
        private System.Windows.Forms.TextBox ProdName;
        private System.Windows.Forms.TextBox ProdIDBox;
        private System.Windows.Forms.TextBox TranIDBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}