﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ChangePass : Form
    {
        public static MsUser user = new MsUser();
        public ChangePass()
        {
            InitializeComponent();
        }

        private void ChangePass_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = FormLogin.user.UserID;
                user = db.MsUsers.Where(y => y.UserID == id).FirstOrDefault();
                user.UserPassword = NewPass.Text;

                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
            }
        }
    }
}
