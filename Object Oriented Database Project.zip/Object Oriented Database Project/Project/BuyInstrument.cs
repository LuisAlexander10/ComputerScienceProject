﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{

    public partial class BuyInstrument : Form
    {

        public static int totalharga;
        public static string nama;
        public static string type;
        public static int harga;
        public static int qty;
        public BuyInstrument()
        {
            InitializeComponent();
            loadgrid();
        }

        public void loadgrid() {
           Entities3 db = new Entities3();

      var query = from p in db.MsProducts
                                  join t in db.MsTypes on p.TypeID equals t.TypeId
                                  select new 
                                  {
                                      ProductID = p.ProductID,
                                      TypeName = t.TypeName,
                                      ProductName = p.ProductName,
                                      ProductPrice = p.ProductPrice,
                                      ProductStock = p.ProductStock
                                  };
            dataGridView1.DataSource = query.ToList();
            bindingSource1.DataSource = query.ToList();  
           

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            nama = NameBox.Text;
            type = TypeBox.Text;
            harga = Convert.ToInt32(PriceBox.Text);
            qty = Convert.ToInt32(Quantity.Value);
            totalharga = Convert.ToInt32(TotalBox.Text);

            Payment pay = new Payment();
            pay.Show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

        private void BuyInstrument_Load(object sender, EventArgs e)
        {
          
        }

        private void dataGridView1_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void bindingSource1_CurrentChanged(object sender, EventArgs e)
        {
          
            
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {

            if (dataGridView1.CurrentRow.Index != -1)
            {
                var produkid = Convert.ToString(dataGridView1.CurrentRow.Cells["ProductID"].Value);
                using (Entities3 db = new Entities3())
                {
                    var model = db.MsProducts.Where(x => x.ProductID == produkid).FirstOrDefault();
                    NameBox.Text = model.ProductName;
                    TypeBox.Text = dataGridView1.CurrentRow.Cells["TypeName"].Value.ToString();
                    PriceBox.Text = Convert.ToString(model.ProductPrice);
                    StockBox.Text = Convert.ToString(model.ProductStock);
                }


                harga = Convert.ToInt32(PriceBox.Text);
                qty = Convert.ToInt32(Quantity.Value);


                totalharga = harga * qty;
                TotalBox.Text = Convert.ToString(totalharga);
            }
        }
    }
}
