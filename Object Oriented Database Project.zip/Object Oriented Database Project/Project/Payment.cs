﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Payment : Form
    {
        public Payment()
        {
            InitializeComponent();
        }

        private void Payment_Load(object sender, EventArgs e)
        {
            label11.Text = BuyInstrument.type;
            label10.Text = BuyInstrument.nama;
            label4.Text = Convert.ToString(BuyInstrument.harga);
            label5.Text = Convert.ToString(BuyInstrument.qty);
            label2.Text = Convert.ToString(BuyInstrument.totalharga);
        }
    }
}
