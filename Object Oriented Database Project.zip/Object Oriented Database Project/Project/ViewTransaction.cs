﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class ViewTransaction : Form
    {
        public ViewTransaction()
        {
            InitializeComponent();
        }

        private void ViewTransaction_Load(object sender, EventArgs e)
        {
            Entities3 db = new Entities3();
            var query = from p in db.HeaderTransactions
                        join t in db.DetailTransasctions on p.TransactionID equals t.TransactionID
                        select new
                        {
                            TransactionID = p.TransactionID,
                            UserID = p.UserID,
                            TransactionDate = p.TransactionDate,
                            BikeID = t.ProductID,
                            Duration = t.Quantity
                        };
            dataGridView1.DataSource = query.ToList();
        }

        private void ViewTransaction_MouseClick(object sender, MouseEventArgs e)
        {
           
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var tranid = Convert.ToString(dataGridView1.CurrentRow.Cells["TransactionID"].Value);
                var prodid = Convert.ToString(dataGridView1.CurrentRow.Cells["BikeID"].Value);
                var userid = Convert.ToString(dataGridView1.CurrentRow.Cells["UserID"].Value);
                
                using (Entities3 db = new Entities3())
                {
                    var model1 = db.HeaderTransactions.Where(x => x.TransactionID == tranid).FirstOrDefault();
                    var model2 = db.DetailTransasctions.Where(x => x.TransactionID == tranid).FirstOrDefault();
                    var model3 = db.MsUsers.Where(x => x.UserID == userid).FirstOrDefault();
                    var model4 = db.MsProducts.Where(x => x.ProductID == prodid).FirstOrDefault();
                    var model5 = db.MsTypes.Where(x => x.TypeId == model4.TypeID).FirstOrDefault();
                    TranIDBox.Text = model1.TransactionID;
                    ProdIDBox.Text = model2.ProductID;
                    UserBox.Text = model1.UserID;
                    DateBox.Value = model1.TransactionDate;
                    ProdName.Text = model4.ProductName;
                    ProdPrice.Text = Convert.ToString(model4.ProductPrice);
                    QtyBox.Text = Convert.ToString(model2.Quantity);
                    CustBox.Text = model3.UserName;
                    PhoneBox.Text = model3.UserPhone;
                    AddBox.Text = model3.UserAddress;                  
                    ProdType.Text = model5.TypeName;



                }
            }
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
