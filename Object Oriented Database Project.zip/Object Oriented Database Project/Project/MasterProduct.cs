﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class MasterProduct : Form
    {
        MsProduct produk = new MsProduct();
        public MasterProduct()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var produkid = Convert.ToString(dataGridView1.CurrentRow.Cells["BikeID"].Value);
                using (Entities3 db = new Entities3())
                {
                    var model = db.MsProducts.Where(x => x.ProductID == produkid).FirstOrDefault();
                    IDBox.Text = model.ProductID;
                    NameBox.Text = model.ProductName;
                    PriceBox.Text = Convert.ToString(model.ProductPrice);
                    StockBox.Value = model.ProductStock;
                    TypeBox.Text = dataGridView1.CurrentRow.Cells["Type"].Value.ToString();

                }

            }
        }

        private void MasterProduct_Load(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                var query = from u in db.MsProducts join t in db.MsTypes on u.TypeID equals t.TypeId
                            select new
                            {
                                BikeID = u.ProductID,
                                Type = t.TypeName,
                                Name = u.ProductName,
                                Price = u.ProductPrice,
                                Stock = u.ProductStock,
                              
                            };

                dataGridView1.DataSource = query.ToList();
            }
        }
        private void refresh()
        {
                using (Entities3 db = new Entities3())
                {
                    var query = from u in db.MsProducts
                                join t in db.MsTypes on u.TypeID equals t.TypeId
                                select new
                                {
                                    BikeID = u.ProductID,
                                    Type = t.TypeName,
                                    Name = u.ProductName,
                                    Price = u.ProductPrice,
                                    Stock = u.ProductStock,

                                };

                    dataGridView1.DataSource = query.ToList();
                }
            }
        private void button1_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {

                produk.ProductName = NameBox.Text;
                produk.ProductID = IDBox.Text;
                produk.ProductPrice = Convert.ToInt32(PriceBox.Text);
                produk.ProductStock = Convert.ToInt32(StockBox.Value);
     
                db.MsProducts.Add(produk);
                db.SaveChanges();
              

            }
            refresh();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = IDBox.Text;
                produk = db.MsProducts.Where(y => y.ProductID == id).FirstOrDefault();
                produk.ProductName = NameBox.Text;
                produk.ProductID = IDBox.Text;
                produk.ProductPrice = Convert.ToInt32(PriceBox.Text);
                produk.ProductStock = Convert.ToInt32(StockBox.Value);

                db.Entry(produk).State = EntityState.Modified;
                db.SaveChanges();
            }
            refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = IDBox.Text;
                produk = db.MsProducts.Where(y => y.ProductID == id).FirstOrDefault();
                db.MsProducts.Remove(produk);
                db.SaveChanges();
            }
            refresh();
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }
    }
}
