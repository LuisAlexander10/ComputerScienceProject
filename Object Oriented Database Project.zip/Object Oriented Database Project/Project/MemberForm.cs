﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class MemberForm : Form
    {
        public MemberForm()
        {
            InitializeComponent();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePass ChangePass = new ChangePass();
            ChangePass.Show();
        }

        private void buyInstrumentToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void memberToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void buyInstrumentToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            BuyInstrument buy = new BuyInstrument();
            buy.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MemberForm_Load(object sender, EventArgs e)
        {

        }
    }
}
