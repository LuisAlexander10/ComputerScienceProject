﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class FormRegis : Form
    {
        MsUser user = new MsUser();
        string Gender;
        public FormRegis()
        {
            InitializeComponent();
        }

        private void FormRegis_Load(object sender, EventArgs e)
        {

        }
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Male";
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            Gender = "Female";
        }
        private void button1_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            { 

            user.UserName = NameBox.Text;
            user.UserPassword = PassBox.Text;
            user.UserPhone = PhoneBox.Text;
            user.UserRole = "Member";
                user.UserID = mid.Text;
            user.UserDOB = DOB1.Value;
            user.UserAddress = AddBox.Text;
            user.UserGender = Gender;
            user.UserEmail = EmailBox.Text;

            db.MsUsers.Add(user);
            db.SaveChanges();
              

            }
        }
       }


    }

