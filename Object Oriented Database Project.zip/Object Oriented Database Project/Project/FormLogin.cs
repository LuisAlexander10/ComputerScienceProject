﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Project
{
    public partial class FormLogin : Form
    {
        public static MsUser user = new MsUser();
        public FormLogin()
        {
            InitializeComponent();
        }

        private void FormLogin_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void LoginBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                user = db.MsUsers.Where(
                    x => x.UserEmail == EmailBox.Text &&
                    x.UserPassword == PasswordBox.Text).FirstOrDefault();
                if (user == null) MessageBox.Show("Username/Password salah!");
                else if (user.UserRole == "Member")
                {
                    MemberForm memfor = new MemberForm();
                    memfor.Show();
                    StaffForm stafor = new StaffForm();
                    stafor.Show();
                }
                else if(user.UserRole == "admin")
                {
                    StaffForm stafor = new StaffForm();
                    stafor.Show();
                }

            }
        }

        public void EmailBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
