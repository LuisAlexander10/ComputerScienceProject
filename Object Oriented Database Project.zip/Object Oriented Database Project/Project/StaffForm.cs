﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class StaffForm : Form
    {
        public StaffForm()
        {
            InitializeComponent();
        }

        private void productToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void StaffForm_Load(object sender, EventArgs e)
        {

        }

        private void usersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterUser masus = new MasterUser();
            masus.Show();
        }

        private void instrumentToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterProduct maspro = new MasterProduct();
            maspro.Show();
        }

        private void viewTransactionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ViewTransaction view = new ViewTransaction();
            view.Show();
        }

        private void typesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MasterType tipe = new MasterType();
            tipe.Show();
        }

        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ChangePass cp = new ChangePass();
            cp.ShowDialog();
        }
    }
}
