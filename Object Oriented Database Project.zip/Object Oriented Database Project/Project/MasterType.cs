﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class MasterType : Form
    {
        MsType tipe = new MsType();
        public MasterType()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MasterType_Load(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                var query = from u in db.MsTypes
                            select new
                            {
                                TypeID = u.TypeId,
                                TypeName = u.TypeName,
                               
                            };

                dataGridView1.DataSource = query.ToList();
            }
        }
        private void refresh()
        {
            using (Entities3 db = new Entities3())
            {
                var query = from u in db.MsTypes
                            select new
                            {
                                TypeID = u.TypeId,
                                TypeName = u.TypeName,
                            };

                dataGridView1.DataSource = query.ToList();
            }
        }
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var typeid = Convert.ToString(dataGridView1.CurrentRow.Cells["TypeID"].Value);
                using (Entities3 db = new Entities3())
                {
                    var model = db.MsTypes.Where(x => x.TypeId == typeid).FirstOrDefault();
                    IDBox.Text = model.TypeId;
                    NameBox.Text = model.TypeName;
                }
            }
       }

        private void InsertBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {

                tipe.TypeName = NameBox.Text;
                tipe.TypeId= IDBox.Text;
               

                db.MsTypes.Add(tipe);
                db.SaveChanges();
    

            }
            refresh();
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = IDBox.Text;
                tipe = db.MsTypes.Where(y => y.TypeId == id).FirstOrDefault();
                tipe.TypeName = NameBox.Text;
                tipe.TypeId = IDBox.Text;

                db.Entry(tipe).State = EntityState.Modified;
                db.SaveChanges();
            }
            refresh();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = IDBox.Text;
                tipe = db.MsTypes.Where(y => y.TypeId == id).FirstOrDefault();
                db.MsTypes.Remove(tipe);
                db.SaveChanges();
            }
            refresh();
        }
    }
}
