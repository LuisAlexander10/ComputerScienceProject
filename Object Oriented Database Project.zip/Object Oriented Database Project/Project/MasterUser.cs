﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class MasterUser : Form
    {
        MsUser user = new MsUser();
        string gender;
        int x = 1;
        public MasterUser()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void MasterUser_Load(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                var query = from u in db.MsUsers
                            select new
                            {
                                UserID = u.UserID,
                                UserRole = u.UserRole,
                                UserName = u.UserName,
                                UserPassword = u.UserPassword,
                                UserGender = u.UserGender,
                                UserDOB = u.UserDOB,
                                UserPhone = u.UserPhone,
                                UserAddress = u.UserEmail,
                                UserEmail = u.UserEmail
                            };

                dataGridView1.DataSource = query.ToList();
            }


        }
        private void refresh()
        {
            using (Entities3 db = new Entities3())
            {
                var query = from u in db.MsUsers
                            select new
                            {
                                UserID = u.UserID,
                                UserRole = u.UserRole,
                                UserName = u.UserName,
                                UserPassword = u.UserPassword,
                                UserGender = u.UserGender,
                                UserDOB = u.UserDOB,
                                UserPhone = u.UserPhone,
                                UserAddress = u.UserEmail,
                                UserEmail = u.UserEmail
                            };

                dataGridView1.DataSource = query.ToList();
            }
        }

        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.CurrentRow.Index != -1)
            {
                var userid = Convert.ToString(dataGridView1.CurrentRow.Cells["UserID"].Value);
                using (Entities3 db = new Entities3())
                {
                    var model = db.MsUsers.Where(x => x.UserID == userid).FirstOrDefault();
                    IDBox.Text = dataGridView1.CurrentRow.Cells["UserID"].Value.ToString();
                    NameBox.Text = model.UserName;
                    EmailBox.Text = dataGridView1.CurrentRow.Cells["UserEmail"].Value.ToString();
                    AddBox.Text = dataGridView1.CurrentRow.Cells["UserAddress"].Value.ToString();
                    PhoneBox.Text = Convert.ToString(model.UserPhone);
                    if(dataGridView1.CurrentRow.Cells["UserGender"].Value.ToString() == "Male")
                    {
                        MaleBtn.Select();
                    }
                    else
                    {
                        FemaleBtn.Select();
                    }
                    DOB.Value = Convert.ToDateTime(dataGridView1.CurrentRow.Cells["UserDOB"].Value);
                    if(dataGridView1.CurrentRow.Cells["UserRole"].Value.ToString() == "Member")
                    {
                        RoleBox.Text = "Member";
                    }
                    else
                    {
                        RoleBox.Text = "Staff";
                    }


                }
            }
        }
     
        private void InsertBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
              
                user.UserName = NameBox.Text;
                user.UserPassword = "default";
                user.UserRole = Convert.ToString(RoleBox.Text);
                user.UserDOB = DOB.Value;
                user.UserPhone = PhoneBox.Text;
                user.UserGender = gender;
                user.UserAddress = AddBox.Text;
                user.UserEmail = EmailBox.Text;
                user.UserID = "US" + x.ToString().PadLeft(3, '0');
              
                db.MsUsers.Add(user);
                db.SaveChanges();
                x++;
            
            }
            refresh();
        }

        private void MaleBtn_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Male";
        }

        private void FemaleBtn_CheckedChanged(object sender, EventArgs e)
        {
            gender = "Female";
        }

        private void UpdateBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = IDBox.Text;
                user = db.MsUsers.Where(y => y.UserID == id).FirstOrDefault();
                user.UserName = NameBox.Text;
                user.UserRole = Convert.ToString(RoleBox.Text);
                user.UserDOB = DOB.Value;
                user.UserPhone = PhoneBox.Text;
                user.UserGender = gender;
                user.UserAddress = AddBox.Text;
                user.UserEmail = EmailBox.Text;

                db.Entry(user).State = EntityState.Modified;
                db.SaveChanges();
            }
            refresh();
        }

        private void DeleteBtn_Click(object sender, EventArgs e)
        {
            using (Entities3 db = new Entities3())
            {
                string id = IDBox.Text;
                user = db.MsUsers.Where(y => y.UserID == id).FirstOrDefault();
                db.MsUsers.Remove(user);
                db.SaveChanges();
            }
            refresh();
        }
    }
}
