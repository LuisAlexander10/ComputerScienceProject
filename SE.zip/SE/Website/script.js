function myFunction1() {
  var txt;
  if (confirm("You've voted for Jokowi-Amin")) {
    txt = "You pressed Yes!";
  } else {
    txt = "You pressed Cancel!";
  }
  document.getElementsByClassName("vote-now-jokowi").innerHTML = txt;
}

function myFunction2() {
    var txt;
    if (confirm("You've voted for Prabowo-Sandi")) {
      txt = "You pressed Yes!";
    } else {
      txt = "You pressed Cancel!";
    }
    document.getElementsByClassName("vote-now-prabowo").innerHTML = txt;
  }

