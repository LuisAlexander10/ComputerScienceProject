function info1(){
    var apa=document.createElement("img");
    apa.src = "jokowi amin.jpg";
}