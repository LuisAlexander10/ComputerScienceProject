function validateName(){
    var x = document.getElementById("fName").value;
    if(x == null || x==""){
        errorfName.innerHTML = "First name must be filled out";
        return false;
    }
}

function validateName2(){
    var y = document.getElementById("lName").value;
    if(y == null || y==""){
        errorlName.innerHTML = "Last name must be filled out";
        return false;
    }
}

function validateAddress(){
    var ad = document.getElementById("address").value;
    if(ad  == "" || ad == null){
        errorAddress.innerHTML = "Address must be filled out";
        return false;
    }
}

function validateGender(){
    let gender = form.elements["gender"].value;
    let errorGender = document.getElementById("errorGender");
    errorGender.innerHTML = "";
    if(gender == "" || gender == null){
        errorGender.innerHTML = "Gender must be choosed";
        return false;
    }

    // var g = document.getElementById("gender").value;
    // var errorGender = document.getElementById("errorGender");
    // errorGender.innerHTML = "";
    // if(g == "" || g == null){
    //     errorGender.innerHTML = "Gender must be choosed";
    //     return false;
    // }
}

function validateHelmet(){
    var y = document.getElementById("helmetOpt").value;
    if(y==""){
        errorHelmet.innerHTML = "Must choose a helmet";
        // alert("First name must be filled out");
        return false;
    }
}