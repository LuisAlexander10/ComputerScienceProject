function formSubmit(event){
    event.preventDefault();
    let form = event.target;
    let name = form.elements["fName"].value;
    let lname = form.elements["lName"].value;
    let gender = form.elements["gender"].value;
    let address = form.elements["address"].value;
    let helmet = form.elements["helmet"].value;
    let validation = validator(agree);
}

function validator(agree){

    let errorName = document.getElementById("errorfName");
    errorName.innerHTML = "";
    let errorlName = document.getElementById("errorlName");
    errorlName.innerHTML = "";
    let errorGender = document.getElementById("errorGender");
    errorGender.innerHTML = "";
    let errorAddress = document.getElementById("errorAddress");
    errorAddress.innerHTML = "";
    let errorHelmet = document.getElementById("errorHelmet");
    errorHelmet.innerHTML = "";

    if(name=="" || name==false){
        errorName.innerHTML ="Name must be filled";
        return false;
    }
    if(lname=="" || lname==false){
        errorlName.innerHTML ="Last Name must be filled";
        return false;
    }
    if(gender=="" || gender==false){
        errorGender.innerHTML ="ender must be choosed";
        return false;
    }
    if(address=="" || address==false){
        errorAddress.innerHTML ="Address must be filled";
        return false;
    }
    if(helmet=="" || helmet==false){
        errorHelmet.innerHTML ="You must choose a product";
        return false;
    }
    return true;
}