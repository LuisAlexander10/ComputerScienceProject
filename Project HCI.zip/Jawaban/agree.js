function formSubmit(event){
    event.preventDefault();
    let form = event.target;
    let agree = form.elements["agree"].checked;
    let validation = validator(agree);
}

function validator(agree){
    let errorAgree = document.getElementById("errorAgree");
    errorAgree.innerHTML = "";

    if(agree=="" || agree==false){
        errorAgree.innerHTML ="You must agree with our policy";
        return false;
    }
    return true;
}