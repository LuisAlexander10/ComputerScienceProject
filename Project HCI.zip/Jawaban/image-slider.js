$(document).ready(function(){
    var images = ['Images/dualsport1.jpg', 'Images/fullface3.jpg', 'Images/halfface2.jpg', 'Images/fullface5.jpg'];

    var index = 0;
    var imgObj = $('img[name="slider"]');
    var myTimeout;

    $('#next').click(function(){
        clearTimeout(myTimeout);
        changeSlideprep('next');
    });

    $('#prev').click(function(){
        clearTimeout(myTimeout);
        changeSlideprep('prev');
    });

    function changeSlideprep(status){
        imgObj.fadeOut(1000, function(){
            changeSlide(status);
        });
        myTimeout = setTimeout(changeSlideprep,2000);
    }

    function changeSlide(status){
        imgObj.fadeIn(1500);

        if(status != 'prev'){
            if(index < images.length -1)
            index++;
            else
            index = 0;
        }else{
            if(index == 0)
            index = images.length - 1;
            else
            index--;
        }

        

            imgObj.attr("src", images[index]);
    }

    imgObj.attr("src", images[index]);
    myTimeout = setTimeout(changeSlideprep, 3000);
});